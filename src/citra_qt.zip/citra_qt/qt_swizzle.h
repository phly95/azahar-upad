// Copyright Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

namespace QtSwizzle {

void Dummy();

} // namespace QtSwizzle
